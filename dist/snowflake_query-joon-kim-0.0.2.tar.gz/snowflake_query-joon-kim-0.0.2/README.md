# Query from Snowflake

Assists Snowflake query from Python
Outputs query results in Pandas DataFrame
Uses unencrypted private key for Snowflake credentials